#include "head_list.h"
#include "list.h"


int main (void) {

	Queue queue = {};
	int capacity = 4;
	CHECK_ERROR (ListCreator (&queue, capacity), "Problem with creating QUEUE.");

	FILE * dumpFile      =              fopen ("dumpfile.txt", "w");
	CHECK_ERROR(dumpFile == NULL, "Problem with opening DUMPFILE.");
	
	ListDump (&queue, dumpFile);
	return 0;
}
