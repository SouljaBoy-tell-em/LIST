#include <stdio.h>

int main (void)
{
	int array[8] = {1,2,3,4,5,6,7,8};
	array [-5] = 228;

	for (int i = 0; i < 8; i++)
		printf ("%d ", array[i]);
   
}