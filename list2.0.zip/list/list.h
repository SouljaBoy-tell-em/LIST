void startInitialize (Queue * queue) {

	queue->next[0] = 				   0;
	queue->data[0] = 				   0;
	queue->data[queue->capacity - 1] = 0;
	queue->prev[0] =				   0;

	int i = 0;
	for (i = 1; i < queue->capacity; i++) {

		queue->prev[i] = -1;
		queue->next[i] = -1;
		queue->data[i] = 0;
	}
}


int ListCreator (Queue * queue, int capacity) {


	queue->head     		   = 		0;
	queue->tail     		   =        0;
	queue->size 			   = 		0;
	queue->capacity 		   = capacity;

	queue->prev = (int * ) calloc (capacity, sizeof (int)	);
	CHECK_ERROR (queue->prev == NULL, "Problem with allocating memory for queue->prev.");
	queue->next = (int * ) calloc (capacity, sizeof (int)	);
	CHECK_ERROR (queue->prev == NULL, "Problem with allocating memory for queue->next.");
	queue->data = (Elem_t * ) calloc (capacity, sizeof (Elem_t));
	CHECK_ERROR (queue->prev == NULL, "Problem with allocating memory for queue->data.");

	startInitialize (queue);

	return ERROR_OFF;
}


void ListDump (Queue * queue, FILE * dumpFile) {

	fprintf (dumpFile, "digraph G {\n rankdir=LR\n");

	int i = 0;
	for (i = 0; i < queue->size - 1; i++) 	{

		fprintf (dumpFile, "block%d [shape=record, color=\"green\", label=\"block %d| {data %d | next %d | prev %d }\""
				 "];\n", i, i + 1, queue->data[i], queue->next[i], queue->prev[i]);
	}

	fprintf (dumpFile, "block%d [shape=record, color=\"green\", label=\"block %d| {data %d | next %d | prev %d }\""
				   "];\n", queue->size - 1, queue->size, queue->data[queue->size - 1], queue->next[queue->size - 1], queue->prev[queue->size - 1]);

	for (i = 0; i < queue->size - 1; i++)   {

		if (queue->next[i] == 0) {

			fprintf (dumpFile, "block%d -> block%d[color = \"pink\"];\n", i, 0);
			break;
		}

		fprintf (dumpFile, "block%d -> block%d[color = \"pink\"];\n", i, i + 1);
	}
	
	fprintf (dumpFile, "block%d -> block%d[color = \"pink\"];\n", queue->size - 1, 0);
	fprintf (dumpFile, "head [shape=record, color=\"orange\", label=\"head\"];\n");
	fprintf (dumpFile, "tail [shape=record, color=\"orange\", label=\"tail\"];\n");
	fprintf (dumpFile, "head -> block%d[color = \"orange\"];\n", 0);
	fprintf (dumpFile, "tail -> block%d[color = \"orange\"];\n", queue->size - 1);	
	fprintf (dumpFile, "}");
}

bool ListInsert (Queue * queue, int indexArgument, Elem_t argument) {

	CHECK_ERROR(indexArgument > queue->capacity, "This element don't insert.\n");

	if (queue->size == 0) {

		queue->size++							  ;	
		queue->data[1] =                  argument;
		queue->next[1] =                         0;
		queue->prev[1] =                         0;
		queue->head    =		     			 1;
		queue->tail    =                         1;

		return true;
	}

	if (queue->size == queue->capacity - 1)
		ListResize (queue);

	queue->prev[indexArgument]              =   queue->tail;
	queue->next[indexArgument]              =   queue->head;
	queue->next[queue->prev[indexArgument]] = indexArgument;
	queue->prev[queue->next[indexArgument]] = indexArgument;
	queue->tail                             = indexArgument;
	queue->data[indexArgument]              =      argument;
	queue->size++										   ;

	return true;
}


void  ListRemove (Queue * queue, int indexArgument) {

	if (indexArgument == queue->head) queue->head = queue->next[indexArgument];
	if (indexArgument == queue->tail) queue->tail = queue->prev[indexArgument];

	queue->prev[queue->next[indexArgument]]       = queue->prev[indexArgument];
	queue->next[queue->prev[indexArgument]]       = queue->next[indexArgument];
	queue->data[indexArgument]                    =                          0;
	queue->prev[indexArgument]                    =                         -1;
	queue->next[indexArgument]                    =                         -1;
	queue->size--                                                             ;
}


bool ListResize (Queue * queue) {

	queue->capacity = RATIOQUEUECOEFFICIENT * queue->capacity;

	queue->data = (Elem_t * ) realloc (queue->data, sizeof (Elem_t) * queue->capacity            );
	CHECK_ERROR (queue->data == NULL, "Problem with allocating memory for queue->data. (realloc)");
	queue->next = (Elem_t * ) realloc (queue->next, sizeof (Elem_t) * queue->capacity            );
	CHECK_ERROR (queue->next == NULL, "Problem with allocating memory for queue->next. (realloc)");
	queue->prev = (Elem_t * ) realloc (queue->prev, sizeof (Elem_t) * queue->capacity            );
	CHECK_ERROR (queue->prev == NULL, "Problem with allocating memory for queue->prev. (realloc)");

	UninitializeElements (queue);

	return true;
}


void logicalSort (Queue * queue) {

	Queue capacityQueue = 													 {};
	capacityQueue.data  = (Elem_t * ) calloc (queue->capacity, sizeof (Elem_t));
	capacityQueue.next  = (int    * ) calloc (queue->capacity, sizeof (Elem_t));
	capacityQueue.prev  = (int    * ) calloc (queue->capacity, sizeof (Elem_t));

	int i = 0, index = queue->head;
	for (i = 0; i < queue->size; i++) {

		capacityQueue.data[i] = queue->data[index];
		capacityQueue.next[i] = queue->next[index];
		capacityQueue.prev[i] = queue->prev[index];
		index                 = queue->next[index];
	}


	for (i = 0; i < queue->size; i++) {

		queue->data[i] = capacityQueue.data[i];
		queue->next[i] = capacityQueue.next[i];
		queue->prev[i] = capacityQueue.prev[i];
	}

	for (i = queue->size; i < queue->capacity; i++) {

		queue->data[i] = 0;
		queue->next[i] = 0;
		queue->prev[i] = 0;
	}

	free (capacityQueue.data);
	free (capacityQueue.next);
	free (capacityQueue.prev);
}


void UninitializeElements (Queue * queue) {

	int i = 0;
	for (i = queue->size + 1; i < queue->capacity; i++) {

		queue->next[i] = -1;
		queue->prev[i] = -1;
		queue->data[i] =  0;
	}
}