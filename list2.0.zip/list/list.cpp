#include "head_list.h"
#include "list.h"


int main (void) {

	Queue queue = {};
	int capacity = 5;
	CHECK_ERROR (ListCreator (&queue, capacity), "Problem with creating QUEUE.");

	FILE * dumpFile      =              fopen ("dumpfile.txt", "w");
	CHECK_ERROR(dumpFile == NULL, "Problem with opening DUMPFILE.");


	ListInsert (&queue, 2, 228);
	ListInsert (&queue, 4, 229);
	ListInsert (&queue, 3, 230);
	ListInsert (&queue, 2, 231);
	ListInsert (&queue, 5, 232);
	ListInsert (&queue, 19, 233);
	logicalSort (&queue);

	printf ("SIZE: %d\n", queue.size);
	printf ("CAPACITY: %d\n", queue.capacity);
	printf ("HEAD: %d\n", queue.head);
	printf ("TAIL: %d\n", queue.tail);

	printf ("\nLIST: ");
	for (int i = 0; i < queue.capacity; i++)
		printf ("%3d ", queue.data[i]);
	printf ("\nNEXT: ");
	for (int i = 0; i < queue.capacity; i++)
		printf ("%3d ", queue.next[i]);
	printf ("\nPREV: ");
	for (int i = 0; i < queue.capacity; i++)
		printf ("%3d ", queue.prev[i]);
	
	ListDump (&queue, dumpFile);
	return 0;
}
